import { ArrowDown } from 'lucide-react';
import backgroundImage from 'figma:asset/bc498c61a2fc0848a0568f0cc5987732669cd484.png';
import profileImage from 'figma:asset/3162dbe883377956ba47738284bf09c7fe1122bb.png';

export function Hero() {
  const scrollToPortfolio = () => {
    const element = document.getElementById('portfolio');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center pt-16 relative">
      <div className="absolute inset-0 z-0">
        <img 
          src={backgroundImage} 
          alt="Background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40"></div>
      </div>
      <div className="container mx-auto px-4 py-20 text-center relative z-10">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8 flex justify-center">
            <img 
              src={profileImage} 
              alt="Srinivasa Bala" 
              className="w-48 h-48 rounded-full object-cover border-4 border-white shadow-2xl"
            />
          </div>
          <h1 className="text-white mb-6">
            Creative Designer &<br />Visual Storyteller
          </h1>
          <p className="text-white/90 mb-8 max-w-2xl mx-auto">
            I craft compelling visual experiences that blend creativity with strategy. 
            Specializing in brand identity, digital design, and everything in between.
          </p>
          <button 
            onClick={scrollToPortfolio}
            className="inline-flex items-center gap-2 bg-white text-gray-900 px-8 py-3 rounded-full hover:bg-gray-100 transition-colors"
          >
            View My Work
            <ArrowDown size={20} />
          </button>
        </div>
      </div>
    </section>
  );
}