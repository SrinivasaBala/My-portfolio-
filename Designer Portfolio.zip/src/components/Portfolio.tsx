import { ImageWithFallback } from './figma/ImageWithFallback';
import backgroundImage from 'figma:asset/bc498c61a2fc0848a0568f0cc5987732669cd484.png';

const projects = [
  {
    id: 1,
    title: 'Brand Identity Design',
    category: 'Branding',
    image: 'https://images.unsplash.com/photo-1762787863004-767d5d7eac07?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMGlkZW50aXR5JTIwbG9nbyUyMGRlc2lnbnxlbnwxfHx8fDE3NjU3NzY3ODV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Complete brand identity for a modern tech startup'
  },
  {
    id: 2,
    title: 'Poster Design',
    category: 'Poster Design',
    image: 'https://images.unsplash.com/photo-1655156871717-ccda8ae8274c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmFwaGljJTIwcG9zdGVyJTIwZGVzaWdufGVufDF8fHx8MTc2NTg2MDMzMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Creative poster design for events and campaigns'
  },
  {
    id: 3,
    title: 'Editorial Poster Series',
    category: 'Content InDesign',
    image: 'https://images.unsplash.com/photo-1436809031070-e5451a391628?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZGl0b3JpYWwlMjBtYWdhemluZSUyMGxheW91dHxlbnwxfHx8fDE3NjU3OTI1NTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Contemporary poster design for cultural events'
  },
  {
    id: 4,
    title: 'Product Packaging',
    category: 'Packaging',
    image: 'https://images.unsplash.com/photo-1759563871371-eb0ec31824a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBwcm9kdWN0JTIwcGFja2FnaW5nfGVufDF8fHx8MTc2NTc2ODIzNnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Premium packaging design for luxury cosmetics'
  },
  {
    id: 5,
    title: 'Typography Exploration',
    category: 'Typography',
    image: 'https://images.unsplash.com/photo-1616786294129-20f4b04a25a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0eXBvZ3JhcGh5JTIwbGV0dGVyaW5nJTIwYXJ0fGVufDF8fHx8MTc2NTg1OTg3MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Custom typography and lettering projects'
  },
  {
    id: 6,
    title: 'Photography',
    category: 'Photography',
    image: 'https://images.unsplash.com/photo-1585983549382-4e608379fc1b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBwaG90b2dyYXBoeSUyMHBvcnRmb2xpb3xlbnwxfHx8fDE3NjU4Mjg4Njh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Professional photography and visual storytelling'
  }
];

export function Portfolio() {
  return (
    <section id="portfolio" className="py-20 relative">
      <div className="absolute inset-0 z-0">
        <img 
          src={backgroundImage} 
          alt="Background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-white/85"></div>
      </div>
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-gray-900 mb-4">Selected Work</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              A collection of recent projects showcasing my approach to design and creative problem-solving.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {projects.map((project) => (
              <div 
                key={project.id}
                className="group cursor-pointer"
              >
                <div className="relative overflow-hidden rounded-lg aspect-[4/3] bg-gray-100 mb-4">
                  <ImageWithFallback 
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                      <p className="mb-1">{project.category}</p>
                      <p className="text-gray-300">{project.description}</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-1">
                  <h3 className="text-gray-900">{project.title}</h3>
                  <p className="text-gray-500">{project.category}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}