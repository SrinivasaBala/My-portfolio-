import { Award, Briefcase, GraduationCap } from 'lucide-react';
import backgroundImage from 'figma:asset/bc498c61a2fc0848a0568f0cc5987732669cd484.png';

const skills = [
  'Brand Identity',
  'UI/UX Design',
  'Typography',
  'Poster Design',
  'Digital Illustration',
  'Art Direction',
  'Content InDesign',
  'Photography'
];

const experience = [
  {
    icon: Briefcase,
    title: 'Junior Designer',
    company: 'The Creatives 360°',
    period: '2025 - Present'
  },
  {
    icon: Briefcase,
    title: 'Graphic Design',
    company: 'RP Sarathy Institution',
    period: '2022 - 2026'
  },
];

export function About() {
  return (
    <section id="about" className="py-20 relative">
      <div className="absolute inset-0 z-0">
        <img 
          src={backgroundImage} 
          alt="Background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gray-50/90"></div>
      </div>
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-gray-900 mb-4">About Me</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              With one year of experience in graphic design, I help brands tell their stories through thoughtful and impactful visual design.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            <div>
              <h3 className="text-gray-900 mb-6">My Approach</h3>
              <p className="text-gray-600 mb-4">
                As a passionate graphic designer, I'm driven by the challenge of transforming ideas into compelling visual stories. I approach each project with fresh eyes and enthusiasm, always eager to learn and push creative boundaries.
              </p>
              <p className="text-gray-600 mb-4">
                I focus on understanding client needs and target audiences, combining creativity with strategic thinking to deliver designs that are both visually striking and purposeful.
              </p>
              <p className="text-gray-600">
                When I'm not designing, you can find me seeking inspiration from art, exploring new design trends, and continuously developing my skills to grow as a creative professional.
              </p>
            </div>

            <div>
              <h3 className="text-gray-900 mb-6">Skills & Expertise</h3>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill) => (
                  <span 
                    key={skill}
                    className="px-4 py-2 bg-white rounded-full text-gray-700 border border-gray-200"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-gray-900 mb-8 text-center">Experience & Education</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {experience.map((item, index) => {
                const Icon = item.icon;
                return (
                  <div 
                    key={index}
                    className="bg-white p-6 rounded-lg border border-gray-200"
                  >
                    <div className="w-12 h-12 bg-gray-900 rounded-full flex items-center justify-center mb-4">
                      <Icon className="text-white" size={24} />
                    </div>
                    <h4 className="text-gray-900 mb-1">{item.title}</h4>
                    <p className="text-gray-600 mb-2">{item.company}</p>
                    <p className="text-gray-500">{item.period}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}