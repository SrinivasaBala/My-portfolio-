import { Mail, Linkedin, Instagram, Phone } from 'lucide-react';
import backgroundImage from 'figma:asset/bc498c61a2fc0848a0568f0cc5987732669cd484.png';

const socialLinks = [
  {
    icon: Phone,
    label: 'Phone',
    href: 'tel:+919342517331',
    text: '+91 9342517331'
  },
  {
    icon: Mail,
    label: 'Email',
    href: 'mailto:sv7768818@gmail.com',
    text: 'sv7768818@gmail.com'
  },
  {
    icon: Linkedin,
    label: 'LinkedIn',
    href: 'https://www.linkedin.com/in/srinivasa-bala-a78b55259',
    text: 'linkedin.com/in/srinivasa-bala'
  },
  {
    icon: Instagram,
    label: 'Instagram',
    href: 'https://www.instagram.com/_ra._.ke_',
    text: '@_ra._.ke_'
  },
];

export function Contact() {
  return (
    <section id="contact" className="py-20 relative">
      <div className="absolute inset-0 z-0">
        <img 
          src={backgroundImage} 
          alt="Background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-white/85"></div>
      </div>
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-gray-900 mb-4">Let's Work Together</h2>
          <p className="text-gray-600 mb-12 max-w-2xl mx-auto">
            I'm always interested in hearing about new projects and opportunities. 
            Whether you have a question or just want to say hi, feel free to reach out!
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            {socialLinks.map((link) => {
              const Icon = link.icon;
              return (
                <a
                  key={link.label}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 p-6 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors group"
                >
                  <div className="w-12 h-12 bg-gray-900 rounded-full flex items-center justify-center group-hover:bg-gray-800 transition-colors">
                    <Icon className="text-white" size={20} />
                  </div>
                  <div className="text-left">
                    <p className="text-gray-900">{link.label}</p>
                    <p className="text-gray-600">{link.text}</p>
                  </div>
                </a>
              );
            })}
          </div>

          <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-12 text-white">
            <h3 className="text-white mb-4">Ready to Start a Project?</h3>
            <p className="text-gray-300 mb-6">
              Let's discuss how we can bring your vision to life.
            </p>
            <a 
              href="mailto:sv7768818@gmail.com"
              className="inline-flex items-center gap-2 bg-white text-gray-900 px-8 py-3 rounded-full hover:bg-gray-100 transition-colors"
            >
              <Mail size={20} />
              Get in Touch
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}